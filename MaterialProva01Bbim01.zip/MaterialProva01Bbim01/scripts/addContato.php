<?php
require_once '../funcoes/init.php';
$nome = isset($_POST['nome']) ? $_POST['nome'] : null;
$dataNascimento = isset($_POST['dataNascimento']) ? $_POST['dataNascimento'] : null;
$telefone = isset($_POST['telefone']) ? $_POST['telefone'] : null;
$email = isset($_POST['email']) ? $_POST['email'] : null;
if (empty($nome) || empty($dataNascimento) || empty($telefone) || empty($email))
{
    echo "Volte e preencha todos os campos";
    exit;
}
$PDO = db_connect();
$sql = "INSERT INTO contatos(nomeContato, dataNascimento, telefone, email) VALUES(:nome, :dataNascimento, :telefone, :email)";
$stmt = $PDO->prepare($sql);
$stmt->bindParam(':nome', $nome);
$stmt->bindParam(':dataNascimento', $dataNascimento);
$stmt->bindParam(':telefone', $telefone);
$stmt->bindParam(':email', $email);

if ($stmt->execute())
{
    header('Location: ../html/msgSucesso.html');
}
else
{
    echo "Erro ao cadastrar";
    print_r($stmt->errorInfo());
}
?>